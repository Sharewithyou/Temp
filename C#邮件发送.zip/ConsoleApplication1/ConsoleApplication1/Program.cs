﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            SendMail();
        }
        public static void SendMail()
        {
            SmtpClient client = new SmtpClient();
            MailMessage mail = new MailMessage();
            try
            {

                ////邮件服务器
                //client.Host = "smtp.qq.com";

                ////smtp主机上的端口号,默认是.
                //client.Port = 25;

                //邮件服务器
                client.Host = "smtp.exmail.qq.com";

                //smtp主机上的端口号,默认是.
                client.Port = 25;

                //邮件发送方式:通过网络发送到SMTP服务器 
                client.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;

                client.EnableSsl = true;

                client.UseDefaultCredentials = false;

                //凭证,发件人登录邮箱的用户名和密码
                //client.Credentials = new System.Net.NetworkCredential("2664244560@qq.com", "nbwonggapontdidg");

                client.Credentials = new System.Net.NetworkCredential("huwei@51baoy.com", "CRWpKQmiZackf6ty");

                //创建一个电子邮件类


                //1,发件人
                mail.From = new MailAddress("huwei@51baoy.com", "保游网服务邮箱"); //发件人

                //2,收件人地址，可多个

                mail.To.Add("warmwei1988@gmail.com");
                mail.To.Add("share_wei@163.com");
                mail.To.Add("2664244560@qq.com");

                mail.Subject = "保游网测试邮件";//邮件标题

                mail.Body = GetBody();//邮件内容

                mail.BodyEncoding = System.Text.Encoding.UTF8;//邮件格式

                mail.IsBodyHtml = true;//设置邮件为HTML格式

                mail.Priority = System.Net.Mail.MailPriority.High;//设置邮件的发送级别 

                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnSuccess;//获取邮件发送状态

                client.Send(mail);//发送邮件
            }
            catch (SmtpFailedRecipientsException ex)
            {
                for (int i = 0; i < ex.InnerExceptions.Length; i++)
                {
                    SmtpStatusCode status = ex.InnerExceptions[i].StatusCode;
                    if (status == SmtpStatusCode.MailboxBusy ||
                        status == SmtpStatusCode.MailboxUnavailable)
                    {
                        Console.WriteLine("Delivery failed - retrying in 5 seconds.");
                        System.Threading.Thread.Sleep(5000);
                        client.Send(mail);
                    }
                    else
                    {
                        Console.WriteLine("Failed to deliver message to {0}", ex.FailedRecipient[i]);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        public static string GetBody()
        {
            string str = @"<div style='margin:0 auto; width:700px; height:auto;border:1px solid #bfbfbf;font:15px 微软雅黑;color:#696969;'>   
             <div name='headerCon' style='padding:30px 0px;'>      
              <div name='header' style='width: 96%;height:80px;margin:0 auto;border-bottom:1px solid #bfbfbf;'>    
                                 <div name='logo' style='float:left;margin-left: 8px; '>
                  <a href='http://www.51baoy.com/'><img src='http://www.51baoy.com/Centent/images/logo.jpg' alt='保游网'></a></div>                 
                    <div naem='phone' style='float: right;position: relative'>                 
                         <img src='http://static.51baoy.com/images/51baoy/mail_kfrx.jpg'>           
                               <strong style='color: #179cda;font-size: 20px;position: absolute;left: 56px;top: 26px;;'>4001-882-892</strong></div></div></div><div name='bobyCon' style='width: 90%;height:auto;margin: 0 auto; margin-bottom: 85px'>
    <p>尊敬的<strong style='color:#179cda '>#UserName#</strong>：</p><p style='line-height: 22px;'>您购买的<strong style='color:#179cda '>#ProductName#</strong>已承保,保单号:<strong style='color:#179cda '>#PolicyCode#</strong>,保单信息请查看附件。如未收到保单或保单有问题请及时联系保游网客服：<span>4001-882-892</span>（服务时间：8:30-24:00）</p>
    <div name='tableCon' style='margin-top: 40px; '><p>订单明细：</p>
    <div><table style='border:1px solid #bfbfbf;border-top:3px solid #179cda;width: 100%; text-align: center;' cellspacing='0' cellpadding='5'><thead><tr><th style='border-right:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf; '>产品名称</th><th style='border-right:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf; '>保险期限</th><th style='border-right:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf; '>保费</th></tr></thead>
        <tbody><tr><td style='border-right:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf;'>#ProductName#</td><td style='border-right:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf; '>#PolicyDate#</td><td style='border-right:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf; '>#premium#</td></tr></tbody></table></div><!--<p style='margin-top: 40px;padding-left: 30px; background: url(http://static.51baoy.com/images/51baoy/mail_call.gif) 0 2px no-repeat'>温馨提示：该保单的保险及理赔服务有保游网提供。</p>--><div style='float: right;position: relative;margin-top: 20px;'><span style='display: inline-block;position: absolute;left: -70px;top: 22px;'>关注我们</span> <img src='http://static.51baoy.com/images/ewm.png' /> </div></div></div><div name='footCon' style='width: 94.2%;height:37px;background-color:#ddd;margin: 0 auto; padding: 40px 20px;'><p style='line-height: 0px;'> 本邮件由保游网系统发出,请勿直接回复</p><p style='line-height: 8px;'> 如需帮助请联系客服4001-882-892,或联系service@51baoy.com </p></div></div>";
            return str;
        }
    }
}
